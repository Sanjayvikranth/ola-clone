import React from "react";
import banner from "./1.png";
function DownWardBanner() {
  return (
    <div style={{ backgroundImage: `url(${banner})`, height: "70vh" }}></div>
  );
}

export default DownWardBanner;
