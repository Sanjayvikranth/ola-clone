const firebaseConfig = {
  apiKey: "AIzaSyB0z4k3noa0JBSCgTv0ZxKQECFQZ21wMQ0",
  authDomain: "ola-clone-cf4d3.firebaseapp.com",
  projectId: "ola-clone-cf4d3",
  storageBucket: "ola-clone-cf4d3.appspot.com",
  messagingSenderId: "441397717243",
  appId: "1:441397717243:web:fd634bfb75ae8a1da2e85e",
};
